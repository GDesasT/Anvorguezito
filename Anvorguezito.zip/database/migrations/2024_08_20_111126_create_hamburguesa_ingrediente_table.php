<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHamburguesaIngredienteTable extends Migration
{
    // public function up()
    // {
    //     Schema::create('hamburguesa_ingrediente', function (Blueprint $table) {
    //         $table->id();
    //         $table->foreignId('hamburguesa_id')->constrained('productos')->onDelete('cascade');
    //         $table->foreignId('ingrediente_id')->constrained('ingredientes')->onDelete('cascade');
    //     });
    // }

    // public function down()
    // {
    //     Schema::dropIfExists('hamburguesa_ingrediente');
    // }
};
